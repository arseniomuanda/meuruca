<?php

return [
	'cacheInvalidHandlers' => 'A configuração de cache deve ter uma array de $validHandlers.',
	'cacheNoBackup'        => 'A configuração de cache deve ter um handler e um backupHandler definido.',
	'cacheHandlerNotFound' => 'A configuração de cache possui um handler ou backup handler inválido na definição.',
];
